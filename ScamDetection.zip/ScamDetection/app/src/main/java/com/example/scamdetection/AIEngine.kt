package com.example.scamdetection

import kotlin.math.min

object AIEngine {

    private val scamKeywords = listOf(
        "otp", "verify", "bank", "account blocked", "urgent",
        "click link", "win", "lottery", "prize", "kyc",
        "update now", "limited time", "suspended", "refund",
        "job", "earn", "₹", "$"
    )

    private val suspiciousDomains = listOf(
        ".ru", ".tk", ".xyz", "bit.ly", "tinyurl"
    )

    fun analyze(text: String): Pair<Int, String> {
        val cleanText = preprocess(text)

        val ruleScore = ruleBasedScore(cleanText)
        val mlScore = mlScore(cleanText)

        val finalScore = min(100, (0.6 * ruleScore + 0.4 * mlScore).toInt())

        val label = when {
            finalScore > 70 -> "High Risk"
            finalScore > 30 -> "Suspicious"
            else -> "Safe"
        }

        return Pair(finalScore, label)
    }

    private fun preprocess(text: String): String {
        return text.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .trim()
    }

    private fun ruleBasedScore(text: String): Int {
        var score = 0

        scamKeywords.forEach {
            if (text.contains(it)) score += 10
        }

        if (Regex("http[s]?://").containsMatchIn(text)) {
            score += 15
        }

        suspiciousDomains.forEach {
            if (text.contains(it)) score += 20
        }

        if (text.contains("otp") && text.contains("share")) {
            score += 25
        }

        return score
    }

    private fun mlScore(text: String): Int {
        var score = 0

        val words = text.split(" ")

        score += words.count { it.length > 12 } * 2
        score += words.count { it in scamKeywords } * 5

        if (words.size < 5) score += 5
        if (text.contains("!")) score += 5

        return score
    }
}
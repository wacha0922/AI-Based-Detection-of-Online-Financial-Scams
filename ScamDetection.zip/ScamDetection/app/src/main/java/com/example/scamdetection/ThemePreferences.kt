package com.example.scamdetection

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.themePrefDataStore by preferencesDataStore(name = "theme_settings")

object ThemePreference {

    private val DARK_KEY = booleanPreferencesKey("dark_mode")

    fun getTheme(context: Context): Flow<Boolean> {
        return context.themePrefDataStore.data.map { prefs: Preferences ->
            prefs[DARK_KEY] ?: true
        }
    }

    suspend fun saveTheme(context: Context, dark: Boolean) {
        context.themePrefDataStore.edit { prefs ->
            prefs[DARK_KEY] = dark
        }
    }
}
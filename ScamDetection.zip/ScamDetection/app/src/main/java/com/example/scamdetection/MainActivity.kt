package com.example.scamdetection

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            val themeViewModel: ThemeViewModel = viewModel()
            val dark by themeViewModel.dark.collectAsState()

            val navController = rememberNavController()

            MaterialTheme(
                colorScheme = if (dark) darkColorScheme() else lightColorScheme()
            ) {

                Scaffold(
                    bottomBar = {
                        BottomNavBar(navController)
                    }
                ) { padding ->

                    NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier.padding(padding)
                    ) {

                        composable("home") {
                            HomeScreen(navController)
                        }

                        composable("history") {
                            HistoryScreen(navController)
                        }

                        composable("settings") {
                            SettingsScreen(navController, themeViewModel)
                        }
                    }
                }
            }
        }
    }
}
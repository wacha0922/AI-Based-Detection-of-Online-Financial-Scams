package com.example.scamdetection.ui.theme

import androidx.compose.ui.graphics.Color

val ScamPrimaryDark = Color(0xFF00E5FF)
val ScamBackgroundDark = Color(0xFF0B0B0F)
val ScamSurfaceDark = Color(0xFF151821)
val ScamCardDark = Color(0xFF1C2230)
val ScamBorderDark = Color(0xFF3A465C)

val ScamPrimaryLight = Color(0xFF006D77)
val ScamBackgroundLight = Color(0xFFF6F8FB)
val ScamSurfaceLight = Color(0xFFFFFFFF)
val ScamCardLight = Color(0xFFF0F4F8)
val ScamBorderLight = Color(0xFFD5DEE8)

val RiskLow = Color(0xFF22C55E)
val RiskMedium = Color(0xFFFACC15)
val RiskHigh = Color(0xFFEF4444)

val TextDark = Color(0xFFFFFFFF)
val TextLight = Color(0xFF111827)
val MutedDark = Color(0xFFB6C2CF)
val MutedLight = Color(0xFF5B6472)
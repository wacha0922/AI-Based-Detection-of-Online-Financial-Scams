package com.example.scamdetection

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ThemeViewModel(app: Application) : AndroidViewModel(app) {

    private val dataStore = ThemeDataStore(app)

    private val _dark = MutableStateFlow(false)
    val dark: StateFlow<Boolean> = _dark

    init {
        viewModelScope.launch {
            dataStore.darkModeFlow.collect {
                _dark.value = it
            }
        }
    }

    fun toggleTheme() {
        viewModelScope.launch {
            val newValue = !_dark.value
            dataStore.saveTheme(newValue)
        }
    }
}
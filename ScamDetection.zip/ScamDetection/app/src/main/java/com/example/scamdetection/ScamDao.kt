package com.example.scamdetection

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ScamDao {

    @Insert
    suspend fun insert(alert: ScamEntity)

    @Query("SELECT * FROM scam_table ORDER BY timestamp DESC")
    suspend fun getAll(): List<ScamEntity>

    @Query("DELETE FROM scam_table")
    suspend fun deleteAll()
}
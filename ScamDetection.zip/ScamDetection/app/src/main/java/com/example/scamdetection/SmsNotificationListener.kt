package com.example.scamdetection

import android.Manifest
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.annotation.RequiresPermission

class SmsNotificationListener : NotificationListenerService() {

    @RequiresPermission(Manifest.permission.VIBRATE)
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val packageName = sbn.packageName ?: "Unknown"

        val sender = extras.getString("android.title") ?: "Unknown"
        val message = extras.getCharSequence("android.text")?.toString() ?: ""

        if (message.isBlank()) return

        val (risk, type) = AIEngine.analyze(message)
        val source = getSourceFromPackage(packageName)

        ScamRepository.add(
            sender = sender,
            message = message,
            risk = risk,
            type = type,
            appPackage = packageName,
            source = source
        )

        if (risk >= 30) {
            NotificationHelper.showScamAlert(
                context = this,
                title = "⚠ $type detected",
                body = "Risk $risk% • From: $sender • Source: $source",
                risk = risk
            )
        }

        if (risk >= 60) {
            vibratePhone()
        }
    }

    private fun getSourceFromPackage(packageName: String): String {
        return when {
            packageName.contains("gmail", ignoreCase = true) -> "Email"
            packageName.contains("gm", ignoreCase = true) -> "Email"
            packageName.contains("mms", ignoreCase = true) -> "SMS"
            packageName.contains("message", ignoreCase = true) -> "SMS"
            packageName.contains("whatsapp", ignoreCase = true) -> "WhatsApp"
            else -> "Other App"
        }
    }

    @RequiresPermission(Manifest.permission.VIBRATE)
    private fun vibratePhone() {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createOneShot(
                    500,
                    VibrationEffect.DEFAULT_AMPLITUDE
                )
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(500)
        }
    }
}

package com.example.scamdetection

data class ScamAlert(
    val sender: String,
    val message: String,
    val risk: Int,
    val type: String,
    val time: String,
    val appPackage: String,
    val source: String
)
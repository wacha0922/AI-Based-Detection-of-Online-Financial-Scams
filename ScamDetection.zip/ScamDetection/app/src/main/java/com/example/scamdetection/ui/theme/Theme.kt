package com.example.scamdetection.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = ScamPrimaryDark,
    background = ScamBackgroundDark,
    surface = ScamSurfaceDark,
    onPrimary = TextLight,
    onBackground = TextDark,
    onSurface = TextDark
)

private val LightColors = lightColorScheme(
    primary = ScamPrimaryLight,
    background = ScamBackgroundLight,
    surface = ScamSurfaceLight,
    onPrimary = TextDark,
    onBackground = TextLight,
    onSurface = TextLight
)

@Composable
fun ScamDetectionTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
package com.example.scamdetection

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun BottomNavBar(navController: NavController) {

    NavigationBar {

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("home") },
            icon = { Text("🏠") },
            label = { Text("Home") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("history") },
            icon = { Text("📜") },
            label = { Text("History") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("highrisk") },
            icon = { Text("⚠️") },
            label = { Text("Risk") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { navController.navigate("settings") },
            icon = { Text("⚙️") },
            label = { Text("Settings") }
        )
    }
}
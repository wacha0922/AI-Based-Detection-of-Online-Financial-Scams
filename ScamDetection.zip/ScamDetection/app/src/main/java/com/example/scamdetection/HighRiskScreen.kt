package com.example.scamdetection

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.NavController
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HighRiskScreen(nav: NavController) {

    val all = ScamRepository.all()

    val highRisk = all.filter { alert ->
        alert.risk >= 60
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            "High Risk Messages",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(highRisk) { alert ->
                Text("⚠️ ${alert.message}")
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}
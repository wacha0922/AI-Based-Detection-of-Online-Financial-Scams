package com.example.scamdetection

import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ScamRepository {

    // 🔹 Compose UI State
    private val list = mutableStateListOf<ScamAlert>()

    // 🔹 Risk Meter
    var currentRisk = mutableIntStateOf(0)
        private set

    // 🔹 Background Scope
    private val scope = CoroutineScope(Dispatchers.IO)

    // 🔥 ROOM DATABASE (Initialized from MainActivity)
    lateinit var db: AppDatabase

    /**
     * Add new scam alert (DB + UI safe)
     */
    fun add(
        sender: String,
        message: String,
        risk: Int,
        type: String,
        appPackage: String,
        source: String
    ) {
        scope.launch {
            try {
                val currentTimeMillis = System.currentTimeMillis()

                val formattedTime = SimpleDateFormat(
                    "dd MMM yyyy, hh:mm a",
                    Locale.getDefault()
                ).format(Date(currentTimeMillis))

                // 🔹 Save to Room DB
                val entity = ScamEntity(
                    sender = sender,
                    message = message,
                    risk = risk,
                    type = type,
                    timestamp = currentTimeMillis
                )

                db.scamDao().insert(entity)

                // 🔹 Convert to UI Model
                val alert = ScamAlert(
                    sender = sender,
                    message = message,
                    risk = risk,
                    type = type,
                    appPackage = appPackage,
                    source = source,
                    time = formattedTime
                )

                // 🔹 Update UI safely on Main thread
                withContext(Dispatchers.Main) {
                    list.add(0, alert)
                    currentRisk.intValue = risk
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Get all alerts
     */
    fun all(): List<ScamAlert> = list

    /**
     * Total alerts count
     */
    fun total(): Int = list.size

    /**
     * High Risk (>= 60)
     */
    fun highRiskCount(): Int = list.count { it.risk >= 60 }

    /**
     * Medium Risk (30–59)
     */
    fun mediumRiskCount(): Int = list.count { it.risk in 30..59 }

    /**
     * Low Risk (< 30)
     */
    fun lowRiskCount(): Int = list.count { it.risk < 30 }

    /**
     * Reset current risk meter
     */
    fun resetMeter() {
        currentRisk.intValue = 0
    }

    /**
     * Clear history (UI + DB)
     */
    fun clearHistory() {
        scope.launch {
            try {
                // 🔹 Clear DB
                db.scamDao().deleteAll()

                // 🔹 Clear UI safely
                withContext(Dispatchers.Main) {
                    list.clear()
                    resetMeter()
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Load history from DB (call on app start)
     */
    fun loadFromDb() {
        scope.launch {
            try {
                val data = db.scamDao().getAll()

                val formattedList = data.map {
                    val time = SimpleDateFormat(
                        "dd MMM yyyy, hh:mm a",
                        Locale.getDefault()
                    ).format(Date(it.timestamp))

                    ScamAlert(
                        sender = it.sender,
                        message = it.message,
                        risk = it.risk,
                        type = it.type,
                        appPackage = "Stored",
                        source = "History",
                        time = time
                    )
                }

                withContext(Dispatchers.Main) {
                    list.clear()
                    list.addAll(formattedList)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
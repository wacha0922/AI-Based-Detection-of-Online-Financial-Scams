package com.example.scamdetection

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scam_table")
data class ScamEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sender: String,
    val message: String,
    val risk: Int,
    val type: String,
    val timestamp: Long
)